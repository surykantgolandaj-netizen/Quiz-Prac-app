# Quiz Studio — Automated Cloud APK Builder

You don't need Android Studio or Node.js on your computer. GitHub will compile the native Android APK in the cloud and give you a direct download link.

---

### How to Get Your APK in 2 Minutes:

1. Extract this zip file.
2. In your GitHub repository ([github.com/surykantgolandaj-netizen/Quiz-Prac](https://github.com/surykantgolandaj-netizen/Quiz-Prac)):
   - Upload the files and folders from this zip (`.github/`, `www/`, `package.json`, `capacitor.config.json`).
   - Commit the changes.
3. Click the **Actions** tab at the top of your GitHub repository.
4. You will see **Build Android APK** running.
5. In about 2–3 minutes, the run will turn green with a checkmark. Click on it.
6. Under **Artifacts** at the bottom, click **QuizStudio-APK** to download your ready-to-install Android `.apk`!
